# IT109Assignment > 2024-12-06 5:18pm
https://universe.roboflow.com/leekimchew/it109assignment

Provided by a Roboflow user
License: CC BY 4.0


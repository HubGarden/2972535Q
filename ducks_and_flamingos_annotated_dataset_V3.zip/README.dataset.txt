# IT109Assignment > 2024-11-30 8:33pm
https://universe.roboflow.com/leekimchew/it109assignment

Provided by a Roboflow user
License: CC BY 4.0

